﻿using System.Collections.Generic;

namespace Kapperszaak.Models
{
    public class Kapperszaak
    {
        private string naam;
        private int btwnummer;
        private int kvknummer;
        private string straat;
        private int nummer;
        private string postcode;
        // 1 op veel relatie tussen Kapperszaak en Kapper
        private List<Kapper> kappers = new List<Kapper>();

        public List<Kapper> Kappers
        {
            get { return kappers; }
        }

        public Kapperszaak()
        {
            
        }

        public Kapperszaak(string naam, int btwnummer, int kvknummer, string straat, int nummer, string postcode)
        {
            this.naam = naam;
            this.btwnummer = btwnummer;
            this.kvknummer = kvknummer;
            this.straat = straat;
            this.nummer = nummer;
            this.postcode = postcode;
        }


        public void VoegKapperToe(Kapper kapper)
        {
            kappers.Add(kapper);
        }

        public void VerwijderKapper(Kapper kapper)
        {
            kappers.Remove(kapper);
        }

    }
}