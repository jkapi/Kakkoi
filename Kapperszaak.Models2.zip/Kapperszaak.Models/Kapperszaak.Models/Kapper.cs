﻿namespace Kapperszaak.Models
{
   public enum Geslacht
    {
        Man, 
        Vrouw
    }

    public class Kapper
    {
        private string naam;
        private int nummer;
        private Geslacht geslacht;
        private Kapperszaak kapperszaak;

        public Kapperszaak Kapperszaak
        {
            get { return this.kapperszaak; }

            set { this.kapperszaak = value; }
        }

        public string Naam
        {
            get { return naam; }
        }

        public int Nummer
        {
            get { return nummer; }
        }

        public Geslacht Geslacht
        {
            get { return geslacht; }
        }


        public Kapper()
        {
            
        }

        public Kapper(string naam, int nummer, Geslacht geslacht)
        {
            this.naam = naam;
            this.nummer = nummer;
            this.geslacht = geslacht;
        }

        public void WijsToeAanKapperszaak(Kapperszaak kapperszaak)
        {
            this.kapperszaak = kapperszaak;
        }

        public override string ToString()
        {
            return naam + " - " + nummer;
        }
    }
}