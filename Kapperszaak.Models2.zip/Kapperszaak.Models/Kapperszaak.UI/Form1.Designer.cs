﻿namespace Kapperszaak.UI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbNaam = new System.Windows.Forms.TextBox();
            this.tbNummer = new System.Windows.Forms.TextBox();
            this.btnSlaOp = new System.Windows.Forms.Button();
            this.lbKappers = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // tbNaam
            // 
            this.tbNaam.Location = new System.Drawing.Point(21, 27);
            this.tbNaam.Name = "tbNaam";
            this.tbNaam.Size = new System.Drawing.Size(100, 20);
            this.tbNaam.TabIndex = 0;
            // 
            // tbNummer
            // 
            this.tbNummer.Location = new System.Drawing.Point(21, 70);
            this.tbNummer.Name = "tbNummer";
            this.tbNummer.Size = new System.Drawing.Size(100, 20);
            this.tbNummer.TabIndex = 1;
            // 
            // btnSlaOp
            // 
            this.btnSlaOp.Location = new System.Drawing.Point(46, 113);
            this.btnSlaOp.Name = "btnSlaOp";
            this.btnSlaOp.Size = new System.Drawing.Size(75, 23);
            this.btnSlaOp.TabIndex = 2;
            this.btnSlaOp.Text = "Sla Op";
            this.btnSlaOp.UseVisualStyleBackColor = true;
            this.btnSlaOp.Click += new System.EventHandler(this.btnSlaOp_Click);
            // 
            // lbKappers
            // 
            this.lbKappers.FormattingEnabled = true;
            this.lbKappers.Location = new System.Drawing.Point(179, 27);
            this.lbKappers.Name = "lbKappers";
            this.lbKappers.Size = new System.Drawing.Size(226, 381);
            this.lbKappers.TabIndex = 3;
            this.lbKappers.SelectedValueChanged += new System.EventHandler(this.lbKappers_SelectedValueChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(427, 426);
            this.Controls.Add(this.lbKappers);
            this.Controls.Add(this.btnSlaOp);
            this.Controls.Add(this.tbNummer);
            this.Controls.Add(this.tbNaam);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbNaam;
        private System.Windows.Forms.TextBox tbNummer;
        private System.Windows.Forms.Button btnSlaOp;
        private System.Windows.Forms.ListBox lbKappers;
    }
}

