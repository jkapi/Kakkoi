﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Kapperszaak.Models;

namespace Kapperszaak.UI
{
    public partial class Form1 : Form
    {
        private Models.Kapperszaak kapperszaak;

        public Form1()
        {
            InitializeComponent();

            kapperszaak = new Models.Kapperszaak("Frit's haar shop", 234234, 345345, "Dropstraat", 5, "5859HB");
            
            PopulateListboxKappers();
        }

        private void btnSlaOp_Click(object sender, EventArgs e)
        {
            string naam = tbNaam.Text;
            int nummer = Convert.ToInt32(tbNummer.Text);

            Kapper nieuweKapper = new Kapper(naam, nummer, Geslacht.Man);

            kapperszaak.VoegKapperToe(nieuweKapper);
            nieuweKapper.Kapperszaak = kapperszaak;

            PopulateListboxKappers();

        }

        private void PopulateListboxKappers()
        {
            lbKappers.Items.Clear();

            foreach (Kapper kapper in kapperszaak.Kappers)
            {
                lbKappers.Items.Add(kapper);
            }
        }

        private void lbKappers_SelectedValueChanged(object sender, EventArgs e)
        {
            Kapper geselecteerdeKapper = (Kapper)lbKappers.SelectedItem;
            MessageBox.Show(geselecteerdeKapper.Naam + " " + geselecteerdeKapper.Nummer + " " + geselecteerdeKapper.Geslacht);
        }
    }
}
